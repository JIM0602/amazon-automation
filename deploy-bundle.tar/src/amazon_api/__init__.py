"""Amazon API package."""
