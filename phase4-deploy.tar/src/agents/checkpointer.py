"""LangGraph PostgreSQL checkpointer for conversation state persistence."""
from __future__ import annotations

import logging
from importlib import import_module
from typing import Optional, Protocol, cast

from src.config import settings

logger = logging.getLogger(__name__)

_checkpointer: Optional[object] = None


class _PostgresSaver(Protocol):
    def setup(self) -> None: ...


def _normalize_database_url(db_url: str) -> str:
    """Normalize SQLAlchemy-style PostgreSQL URLs for LangGraph."""
    if "+psycopg2" in db_url:
        return db_url.replace("+psycopg2", "")
    if "+asyncpg" in db_url:
        return db_url.replace("+asyncpg", "")
    return db_url


def get_checkpointer() -> _PostgresSaver:
    """Return the singleton PostgresSaver instance.

    Creates it on first call. The checkpointer uses settings.DATABASE_URL
    to connect to the same PostgreSQL database used by the rest of the app.
    """
    global _checkpointer
    if _checkpointer is None:
        db_url = _normalize_database_url(settings.DATABASE_URL)
        postgres_module = import_module("langgraph.checkpoint.postgres")
        _checkpointer = cast(_PostgresSaver, postgres_module.PostgresSaver.from_conn_string(db_url))
        logger.info("LangGraph PostgresSaver checkpointer initialized")
    return cast(_PostgresSaver, _checkpointer)


def setup_checkpointer() -> None:
    """Create checkpointer tables in the database.

    Should be called once during app startup.
    """
    try:
        cp = get_checkpointer()
        cp.setup()
        logger.info("Checkpointer tables created/verified")
    except Exception as exc:
        logger.error("Failed to setup checkpointer: %s", exc)
        raise
