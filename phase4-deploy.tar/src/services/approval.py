from __future__ import annotations

import logging
import uuid
from typing import Any, cast

from sqlalchemy.orm import Session

from src.db import AgentRun, ApprovalRequest
from src.feishu.notifications import send_approval_request

logger = logging.getLogger(__name__)

_BOSS_ONLY_AGENT_TYPES = {"auditor", "brand_planning"}


class ApprovalService:
    def __init__(self, db: Session):
        self.db = db

    def submit_for_review(
        self,
        agent_type: str,
        agent_run_id: str,
        action_type: str,
        payload: dict[str, Any] | None = None,
        summary: str | None = None,
    ) -> ApprovalRequest:
        run_uuid = uuid.UUID(agent_run_id)
        agent_run = cast(Any, self.db.query(AgentRun).filter(AgentRun.id == run_uuid).first())
        if agent_run is None:
            raise ValueError(f"Agent run not found: {agent_run_id!r}")

        body: dict[str, Any] = dict(payload or {})
        body["agent_type"] = agent_type
        if summary:
            body["summary"] = summary

        approval = ApprovalRequest()
        approval_any = cast(Any, approval)
        approval_any.agent_run_id = run_uuid
        approval_any.action_type = action_type
        approval_any.payload = body
        approval_any.status = "pending"
        self.db.add(approval)
        self.db.commit()
        self.db.refresh(approval)

        try:
            send_approval_request(
                {
                    "agent_type": agent_type,
                    "action_type": action_type,
                    "summary": summary or "New approval request",
                    "approval_id": str(approval.id),
                }
            )
        except Exception:
            logger.warning("Failed to send Feishu notification for approval %s", approval_any.id)

        return approval

    def list_pending(self, user_id: str, role: str) -> list[ApprovalRequest]:
        _ = user_id
        query = self.db.query(ApprovalRequest).join(AgentRun).filter(ApprovalRequest.status == "pending")
        if role == "operator":
            query = query.filter(AgentRun.agent_type.notin_(sorted(_BOSS_ONLY_AGENT_TYPES)))
        return query.order_by(ApprovalRequest.created_at.desc()).all()

    def approve(self, approval_id: str, user_id: str, role: str, comment: str | None = None) -> bool:
        approval = self._get_permitted_approval(approval_id, role)
        if approval is None:
            raise ValueError(f"Approval request not found: {approval_id!r}")
        approval_any = cast(Any, approval)
        if approval_any.status != "pending":
            return False

        payload: dict[str, Any] = dict(approval_any.payload or {})
        if comment:
            payload["review_comment"] = comment
        approval_any.payload = payload
        approval_any.status = "approved"
        approval_any.approved_by = user_id
        self.db.commit()
        return True

    def reject(self, approval_id: str, user_id: str, role: str, comment: str) -> bool:
        approval = self._get_permitted_approval(approval_id, role)
        if approval is None:
            raise ValueError(f"Approval request not found: {approval_id!r}")
        approval_any = cast(Any, approval)
        if approval_any.status != "pending":
            return False

        payload: dict[str, Any] = dict(approval_any.payload or {})
        payload["review_comment"] = comment
        approval_any.payload = payload
        approval_any.status = "rejected"
        approval_any.approved_by = user_id
        self.db.commit()
        return True

    def get_approval(self, approval_id: str) -> ApprovalRequest | None:
        try:
            approval_uuid = uuid.UUID(approval_id)
        except ValueError:
            return None
        return self.db.query(ApprovalRequest).filter(ApprovalRequest.id == approval_uuid).first()

    def _get_permitted_approval(self, approval_id: str, role: str) -> ApprovalRequest | None:
        approval = self.get_approval(approval_id)
        if approval is None:
            return None
        if role == "operator" and self._is_boss_only(approval):
            raise PermissionError("Operator cannot process this approval")
        return approval

    def _is_boss_only(self, approval: ApprovalRequest) -> bool:
        approval_any = cast(Any, approval)
        agent_run = getattr(approval_any, "agent_run", None)
        agent_type = getattr(agent_run, "agent_type", None)
        return agent_type in _BOSS_ONLY_AGENT_TYPES
